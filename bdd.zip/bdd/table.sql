DROP TABLE IF EXISTS ecriture;

DROP TABLE IF EXISTS attribution_prix_auteur;
DROP TABLE IF EXISTS auteur;
DROP TABLE IF EXISTS prix_auteur;

DROP TABLE IF EXISTS attribution_prix_oeuvre;
DROP TABLE IF EXISTS oeuvre;
DROP TABLE IF EXISTS prix_oeuvre;

CREATE TABLE prix_auteur (
	id_prix_auteur INT AUTO_INCREMENT PRIMARY KEY,
	nom_prix_auteur VARCHAR(50) NOT NULL
);

CREATE TABLE auteur (
	id_auteur INT AUTO_INCREMENT PRIMARY KEY,
	nom_auteur VARCHAR(50),
	prenom_auteur VARCHAR(50)
);

CREATE TABLE attribution_prix_auteur (
	id_prix_auteur INT NOT NULL,
	annee INT, 
	id_auteur INT NOT NULL,
	PRIMARY KEY (id_prix_auteur, id_auteur),
	FOREIGN KEY (id_prix_auteur) REFERENCES prix_auteur(id_prix_auteur),
	FOREIGN KEY (id_auteur) REFERENCES auteur(id_auteur),
	CHECK (annee BETWEEN 1900 and 2020)
);

CREATE TABLE prix_oeuvre (
	id_prix_oeuvre INT AUTO_INCREMENT PRIMARY KEY,
	nom_prix_oeuvre VARCHAR(50) NOT NULL
);

CREATE TABLE oeuvre (
	id_oeuvre INT AUTO_INCREMENT PRIMARY KEY,
	nom_oeuvre VARCHAR(100) NOT NULL
);

CREATE TABLE attribution_prix_oeuvre (
	id_prix_oeuvre INT NOT NULL,
	annee INT,
	id_oeuvre INT NOT NULL,
	PRIMARY KEY (id_prix_oeuvre, id_oeuvre),
	FOREIGN KEY (id_prix_oeuvre) REFERENCES prix_oeuvre(id_prix_oeuvre),
	FOREIGN KEY (id_oeuvre) REFERENCES oeuvre(id_oeuvre),
	CHECK (annee BETWEEN 1900 and 2020)
);

CREATE TABLE ecriture (
	id_auteur INT NOT NULL,
	id_oeuvre INT NOT NULL,
	PRIMARY KEY (id_auteur, id_oeuvre),
	FOREIGN KEY (id_auteur) REFERENCES auteur(id_auteur),
	FOREIGN KEY (id_oeuvre) REFERENCES oeuvre(id_oeuvre)
);
